showaxes = false;

function draw() {
  clearscreen(240,240,240);

  fill(0);
  textSize(25);
  text(1,200,200);  

  display();

}